/*
Developed by: Kranthi Kiran
Date: 29-Jan-2016
Description: This file provides all foursquare apis needed for this project.
            It mainly has API to search venues (hotels), to retrieve photos for each place/venue found
            It performs an ajax call to retrieve all this information from forusquare REST API end points
*/
// Global Variables
var apis = {}; //to store all apis

//Foursquare api's base settings
apis.foursquare = {

    clientId: 'SMZD010G3KT4N1MJETNWIRARZK5NZUUCHDAUWKRVOZ2HROOI',

    clientSecret: 'A1QT5D0DYHCXSHK2SEBAKQ5IOVAIIDGNGB1XVI2WXPANNQDE',

    /**
     * To retrieve hotesl based on foursquare venue search API
     * @param {object} locationObj The location object in which places will be searched.
     * @param {function(places)} successCallback The function to call if the request is successful.
     * @param {function(error)} errorCallback The function to call if there was an error.
     * @return {void}
     */
    getPlacesIn: function (locationObj, successCallback, errorCallback) {
        'use strict';
        var endpoint = 'https://api.foursquare.com/v2/venues/search?client_id=' +
            this.clientId +
            '&client_secret=' +
            this.clientSecret +
            '&ll=' +
            locationObj.latitude +
            ',' +
            locationObj.longitude +
            '&v=20140806&m=foursquare&limit=25&categoryId=4bf58dd8d48988d1fa931735';

        this.get('venues', endpoint, successCallback, errorCallback);
    },

    /**
     * To retrieve photos for each place/venue found by venue API. This uses photos API inside Venue foursquare API end point
     * @param {object} place The place to retrieve the photos for.
     * @param {function(photos)} successCallback The function to call if the request is successful.
     * @param {function(error)} errorCallback The function to call if there was an error.
     * @return {void}
     */
    getPhotosOf: function (place, successCallback, errorCallback) {
        'use strict';
        var endpoint = 'https://api.foursquare.com/v2/venues/' +
                        place.id +
                        '/photos?client_id=' +
                        this.clientId +
                        '&client_secret=' +
                        this.clientSecret +
                        '&v=20140806&m=foursquare';

        this.get('photos', endpoint, successCallback, errorCallback);
    },

    /**
     * Common fundtion to make an Ajax request against to foursquare API end points
     * @param {string} resource The name of the resource to retrieve from the response.
     * @param {string} endpoint The URL of the endpoint.
     * @param {function(resource)} successCallback The function to call if the request is successful.
     * @param {function(error)} errorCallback The function to call if there was an error.
     * @return {void}
     */
    get: function(resource, endpoint, successCallback, errorCallback) {
        'use strict';
        $.get(endpoint)
            .done(function (data) {
                var meta = data.meta;

                if (meta.code === 200) {
                    if (successCallback) {
                        successCallback(data.response[resource]);
                    }

                } else {
                    if (errorCallback) {
                        errorCallback({errorType: meta.errorType, errorDetail: meta.errorDetail});
                    }
                }
            })
            .fail(function () {
                errorCallback('Can not retrieve places. Please reload the page.');
            });
    }
};

/*
Foursquare API end points
************************

CAFE***
https://api.foursquare.com/v2/venues/search?client_id=SMZD010G3KT4N1MJETNWIRARZK5NZUUCHDAUWKRVOZ2HROOI&client_secret=A1QT5D0DYHCXSHK2SEBAKQ5IOVAIIDGNGB1XVI2WXPANNQDE&ll=12.971599,77.594563&v=20140806&m=foursquare&limit=10&categoryId=4bf58dd8d48988d16d941735

HOTEL***
https://api.foursquare.com/v2/venues/search?client_id=SMZD010G3KT4N1MJETNWIRARZK5NZUUCHDAUWKRVOZ2HROOI&client_secret=A1QT5D0DYHCXSHK2SEBAKQ5IOVAIIDGNGB1XVI2WXPANNQDE&ll=12.971599,77.594563&v=20140806&m=foursquare&limit=10&categoryId=4bf58dd8d48988d1fa931735
search:
https://api.foursquare.com/v2/venues/search?client_id=SMZD010G3KT4N1MJETNWIRARZK5NZUUCHDAUWKRVOZ2HROOI&client_secret=A1QT5D0DYHCXSHK2SEBAKQ5IOVAIIDGNGB1XVI2WXPANNQDE&ll=12.971599,77.594563&v=20140806&m=foursquare&limit=10&categoryId=4bf58dd8d48988d1fa931735&query=Marriott

Restaurant***
https://api.foursquare.com/v2/venues/search?client_id=SMZD010G3KT4N1MJETNWIRARZK5NZUUCHDAUWKRVOZ2HROOI&client_secret=A1QT5D0DYHCXSHK2SEBAKQ5IOVAIIDGNGB1XVI2WXPANNQDE&ll=12.971599,77.594563&v=20140806&m=foursquare&limit=10&categoryId=4bf58dd8d48988d10f941735

https://api.foursquare.com/v2/venues/51d1245e498ef93fd0e713bb/photos?client_id=SMZD010G3KT4N1MJETNWIRARZK5NZUUCHDAUWKRVOZ2HROOI&client_secret=A1QT5D0DYHCXSHK2SEBAKQ5IOVAIIDGNGB1XVI2WXPANNQDE&v=20140806&m=foursquare&limit=10

photo:
prefix + widthxheight + suffix
https://irs3.4sqi.net/img/general/960x720/40965064_BbBGkhtq7HbgpJGvkifSjUE4vTolSpzKIFpHEzgu3Gw.jpg

likes:
https://api.foursquare.com/v2/venues/51d1245e498ef93fd0e713bb/likes
https://foursquare.com/explore?mode=url&near=Bangalore Karnataka&nearGeoId=72057594039205269&q=JW Mariott
*/
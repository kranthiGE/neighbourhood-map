/*
Developed by: Kranthi Kiran
Date: 29-Jan-2016
Description: This file uses KnockoutJS as cliend side model M V VM to store places, photos, google maps, map markers, filter objects...
			needed to store & bind the data to UI.
			This has functions that calls individual functions in foursquare.api.js file to retrieve information
*/
//global constants for bootstrap collapse CSS classes
var CONST_CLPSE_OPEN = 'panel-collapse pre-scrollable collapse';//for open
var CONST_CLPSE_CLOSE = 'panel-collapse pre-scrollable collapse in'; // to close

var viewModel = function(){
	'use strict';
	var self = this;

	//boolean variable used to show page loading bar
	self.loadingComplete = ko.observable(false);

	//boolean variable that
	self.error = ko.observable(false);

	//Error text
	self.errorText = ko.observable('');

	//Default location attributes for Bangalore city, IN
	self.location = {
		latitude: 12.971599,
		longitude: 77.594563
	};

	// value of search field
	this.search = ko.observable('');

	//Function to initialize google maps and binds to div UI container with specified settings
	self.initializeMap = function(){

		if(typeof(google) !='object' || typeof(google.maps) != 'object'){
			self.loadingComplete(true);
			self.error(true);
			self.errorText("Google server is not available, please try reloading the page");
			return;
		}

		//Set the variable to Bangalore boundaries
		var cords = new google.maps.LatLng(self.location.latitude, self.location.longitude);

		var mapOptions = {
			zoom: 14,
			center: cords,
			disableDefaultUI: true,
			disableDoubleClickZoom: false
		};
		// This next line makes `map` a new Google Map JavaScript Object and attaches it to
		// <div id="map">, which is appended to UI later.
		self.map = new google.maps.Map(document.querySelector('#map'), mapOptions);

		// Initialize infowindow
		self.mapCard = new google.maps.InfoWindow({
			maxWidth: 200
		});
	};

	// boolean variable for collapse window
	self.isCollapsePnlOpen = ko.observable(true);

	// computed function to dynamically change the collapse window class based on boolean variable
	self.collapsePanelClass = ko.computed(function(){
		return self.isCollapsePnlOpen() ? CONST_CLPSE_OPEN: CONST_CLPSE_CLOSE;

	});

	//function to invoke when hotel list collapse button has been clicked. Toggles the bootstrap css classes based on the boolean
	self.onHotelsListClick = function(){
		if(self.collapsePanelClass() === CONST_CLPSE_OPEN)
			self.isCollapsePnlOpen(false);
		else
			self.isCollapsePnlOpen(true);
	};

	//places array
	self.places = ko.observableArray([]);

	self.searchPlaces = function(){
		//check if an error has occurred previously
		if(self.error()){
			return;
		}
		console.log("searching hotels...");
		//invoke fourspare API though below function
		apis.foursquare.getPlacesIn(self.location, function(places){
			if (places === null || places.length <= 0) {
				self.error(true);
				self.errorText("FourSquare places API did not return results in expected format");
				return;
			}

			// For each retrieved place
			places.forEach(function (place) {
				place.photoPath = ko.observable();

				place.photoVisible = ko.observable(true);

				// Retrieves the photo of the place using the Foursquare API.
				apis.foursquare.getPhotosOf(place, function (photos) {
					place.photos = photos.items;

					if (place.photos.length <= 0) {
						place.photoPath('http://placehold.it/100/FFFFCC/ffffff&text=' + place.name.toUpperCase());
						place.photoVisible(false);
					}
					else{
						place.photoVisible(true);
						// Use the first photo.
						var photo = place.photos[0];
						// Returns the URL of an image of size 100x100 to be used as thumbnail.
						place.photoPath(photo.prefix + '100x100' + photo.suffix);
					}
				});
			});
			self.places(places);

		}, self.handleError);
	};

	//this object at any point will have filtered places that gets bind to places list view
	//this is ko compute function that checks the matching place based on user provided filter
	self.filteredPlaces = ko.computed(function(){
		var searchValue = self.search().toLowerCase();
		if(!searchValue){
			return self.places();
		}
		else{
			return ko.utils.arrayFilter(self.places(), function(item) {
				// return true if found the typed keyword, false if not found.
				return item.name.toLowerCase().indexOf(searchValue) !== -1;
			});
		}
	});

	self.mapMarkers = ko.observableArray([]);

	//called when user clicks on a place header in list view
	self.setPlaceMarker = function(selectedPlace){
		// Change the classname of the collapse panel to close/hide
		self.isCollapsePnlOpen(true);
		// Find index of the clicked location and store for use in activation of marker.
		var index = self.filteredPlaces().indexOf(selectedPlace);

		self.onSelectedPlaceClick(self.mapMarkers[index], selectedPlace);
	};

	// To clear all markers.
	self.clearMapMarkers = function() {
		for (var i = 0, len = self.mapMarkers.length; i < len; i++) {
			self.mapMarkers[i].setMap(null);
		}
		self.mapMarkers = [];
	};

	//creates google markers for each place in the places array.
	self.createMapMarkers = function(data){
		//iterate through places array and create map markers
		self.clearMapMarkers();
		var placesArray = data;
		var bounds;
		if(typeof(placesArray) == 'object' && typeof(google) =='object'){
			//create new bound for map and use it against to each place object's lat & lng
			bounds = new google.maps.LatLngBounds();

			for (var i = 0, len = placesArray.length; i < len; i ++) {
				var location = {
					lat: placesArray[i].location.lat,
					lng: placesArray[i].location.lng
				};

				var marker = new google.maps.Marker({
						position: location,
						map: this.map,
						icon: 'images/pin.png'
					});

				self.mapMarkers.push(marker);

				//render in the map
				self.mapMarkers[i].setMap(this.map);

				bounds.extend(new google.maps.LatLng(location.lat, location.lng));

				placesArray[i].bounds = bounds;

				// add on click event for each marker created on the map
				marker.addListener('click', self.onMapMarkerClick(marker, placesArray[i]));
			}
			this.map.setCenter(bounds.getCenter());
			this.map.fitBounds(bounds);
		}
	};

	// Render all markers with data from the data model.
	self.createMapMarkers(self.places());

	// Subscribe to any change in search input field. Filter the places as and when user starts to type the name of the place
	self.filteredPlaces.subscribe(function(){
		self.createMapMarkers(self.filteredPlaces());
	});

	//To disable or reset all marker icons to original icon
	self.disableAllMarkers = function(){
		self.mapMarkers.forEach(function(marker){
			marker.setIcon('images/pin.png');
		});
	};

	//Common function that creates the map marker card that gets displayed when user clicks on any marker on the map
	self.createMapMarkerCard = function(mapMarker, place){
		//close any opened card
		self.mapCard.close();
		//Change all markers to original
		self.disableAllMarkers();
		//render the card
		self.mapCard.setContent(self.mapCardHtml(place));
		//display the map card
		self.mapCard.open(self.map, mapMarker);
		//pan to the map Card based on lat & long of selected place
		self.map.panTo(new google.maps.LatLng(place.location.lat, place.location.lng));
		/*
		Need to identify the offset height for the map to pan by so that the map card is displayed at the center
		Logic used: 1. Retrieving the top of collapsible div
		2. Retrieving the height of  collapsible div
		3. sum up top position + div height + 100 pixels to position relatively that works for all screens
		*/
		var divCollabsible = $('#collapseListGroupHeading1');
		//Adjust the Y by few negative pizels equivalent to height of texbox+results component so that map card is displayed properly
		self.map.panBy(0, -(divCollabsible.offset().top + divCollabsible.height() + 100));
		//change the icon image
		mapMarker.setIcon('images/pinlg.png');
	};

	//Click event binded to each marker onclick event
	self.onMapMarkerClick = function(mapMarker, place){
		return function(){
			self.createMapMarkerCard(mapMarker, place);
		};
	};

	//click event to each li item in list view
	self.onSelectedPlaceClick = function(mapMarker, place){
		self.createMapMarkerCard(mapMarker, place);
	};

	//builds map marker card HTML
	self.mapCardHtml = function(place){
		//Check if any values or empty and assign them default values
		if(place.location.city === null || place.location.city == 'undefined')
			place.location.city = "Bangalore";
		if(place.location.country === null || place.location.country == 'undefined')
			place.location.country = "India";

		var html = "<div class='card'><div class='card-block'><h4 class='card-title'>" +
					place.name +"</h4><h6 class='card-subtitle text-muted'>" +
					place.categories[0].name + "</h6></div><img src='"+ place.photoPath() +"' class='img-thumbnail'>";

	  		html = html + "<div class='card-block'><p class='card-text text-justify'><b>Address:</b><span>" + place.location.formattedAddress[0] +"</span></p><p class='card-text text-justify'>";

	  		html = html + "<h4><span class='label label-info'>"+ place.location.city + "," + place.location.country +"</span></h4>";

			html = html + "<span>"+ place.stats.checkinsCount +"</span><b> people visited</b></p></div></div>";
		return html;
	};

	//Notifies that there was an error in an API call.
	self.handleError = function (error) {
		self.loadingComplete(true);

		if (error) {
			console.log(error);

			if (typeof error === 'object') {
				self.errorText('Can not retrieve all the places from FourSquare, please try reloading the page');

			} else if (typeof error === 'string') {
				self.errorText(error);
			}
		}

		self.error(true);
	};


};

var model = new viewModel();

function init(){
	model.initializeMap();
	model.searchPlaces();
	model.loadingComplete(true);
}

function mapOnLoadError(){
	console.log('error...');
	model.loadingComplete(true);
	model.error(true);
	model.errorText("Can not load google maps, please try reloading the page");
}

//applies ko bindings after the page load
$(document).ready(function () {
	ko.applyBindings(model);
});